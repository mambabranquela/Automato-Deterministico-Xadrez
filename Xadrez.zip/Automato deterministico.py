# 1ª parte a definição do dicionário


# dicionário { chave        : { chava2 : valor} }
# dicionário { estado_atual : {  letra : próximo_estado } }
# dicionário { Q            : {   T    : conteúdo da célula }}

transicao = {
   'q0': {
       'a': 'q1',
       'b': 'q1', 
       'c': 'q1', 
       'd': 'q1', 
       'e': 'q1', 
       'f': 'q1', 
       'g': 'q1', 
       'h': 'q1', 
       '1': 'q9', 
       'R': 'q2', 
       'T': 'q2', 
       'B': 'q2', 
       'C': 'q2', 
       'D': 'q2', 
       'O': 'q4', 
       '0': 'q7'}, 
    'q1': {
        '1': 'qf1', 
        '2': 'qf1', 
        '3': 'qf1', 
        '4': 'qf1', 
        '5': 'qf1', 
        '6': 'qf1', 
        '7': 'qf1', 
        '8': 'qf3', 
        'x': 'q11'}, 
    'q2': {
        'a': 'q3', 
        'b': 'q3', 
        'c': 'q3', 
        'd': 'q3', 
        'e': 'q3', 
        'f': 'q3', 
        'g': 'q3', 
        'h': 'q3',
        'x': 'q11'}, 
    'q3': {
        '1': 'qf2', 
        '2': 'qf2', 
        '3': 'qf2', 
        '4': 'qf2', 
        '5': 'qf2', 
        '6': 'qf2', 
        '7': 'qf2', 
        '8': 'qf2',
        'x': 'q11'}, 
    'q4': {'O': 'q5'}, 
    'q5': {'-': 'qf5'}, 
    'qf5': {'O': 'q6'}, 
    'q6': {'-': 'qf6'}, 
    'q7': {'-': 'q8'}, 
    'q8': {
        '1': 'qf7', 
        '0': 'qf7'}, 
    'q9': {'-': 'q10'}, 
    'q10': {'0': 'qf8'}, 
    'qf1': {
        '+': 'qf9', 
         '#': 'qf9'}, 
    'qf2': {
        '+': 'qf9', 
        '#': 'qf9'}, 
    'qf10': {
        'T': 'qf11', 
        'B': 'qf11', 
        'C': 'qf11', 
        'D': 'qf11'}, 
    'qf11': {
        '+': 'qf12', 
        '#': 'qf12'}, 
    'q11': {
        'a': 'q12', 
        'b': 'q12', 
        'c': 'q12', 
        'd': 'q12', 
        'e': 'q12', 
        'f': 'q12', 
        'g': 'q12', 
        'h': 'q12'}, 
    'q12': {
        '1': 'qf1', 
        '2':'qf1', 
        '3': 'qf1', 
        '4': 'qf1', 
        '5': 'qf1', 
        '6': 'qf1', 
        '7': 'qf1', 
        '8': 'qf1'},
    'qf3': {'=': 'qf10'}
}

######################################################################################
# 2ª definição do autômato (reconhecimento)


def automato(cadeia):  # definição da função automato ( parametro )

    estado = 'q0'  # definindo o estado inicial
    F = ['qf1', 'qf2', 'qf3', 'qf4', 'qf5', 'qf6', 'qf7', 'qf8', 'qf9', 'qf10', 'qf11', 'qf12']     # conjunto de estado final

    try:  # podemos ficar parados num estado sem definição para a entrada
        for letra in cadeia:    # percorre letra a letra da cadeia entrada
            estado = transicao[estado][letra]    # dicionario [chave1][chave2]

        # qdo lê toda a cadeia porém não alcança o estado final ( a cadeia é um subconjunto
        # das palavras reconhecidas. Ex: fo é subconjunto ( for )
        if estado not in F:
            return 'rejeitada'

    except:  # não conseguir executar todo o for ou seja parou no meio do caminho
        # Ex: erse   não existe transição para a letra r
        return 'rejeitada'

    # ela sai da função significando que ele percorreu toda a cadeia de entrada e alcançou o estado final.
    return 'aceita'

####################################################################################
# 3ª parte de teste
# lê a cadeia de entrada como um arquivo

nome_arquivo = input("informe o nome do arquivo: ")
arquivo = open(nome_arquivo, "r")
entrada = []

# ---------  le linha a linha do arquivo ----------

for linha in arquivo.readlines():

    entrada.extend(linha.split())  # adiciona a linha lida a variavel entrada

arquivo.close()

# ---------------------- ------------------------

for cadeia in entrada:
    print(f'cadeia={cadeia} ==> {automato(cadeia)}')

# ---------------------- ------------------------
